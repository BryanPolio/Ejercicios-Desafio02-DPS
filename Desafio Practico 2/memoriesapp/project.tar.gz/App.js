import React, { useState } from 'react';
import { View, ScrollView, Alert } from 'react-native';
import CapturaImgvideo from './src/components/CapturaImgvideo';
import Display from './src/components/Display';
import SavedMediaList from './src/components/SavedMediaList';
import { styles } from './src/components/styles';

const App = () => {
  const [media, setMedia] = useState(null);
  const [savedMedia, setSavedMedia] = useState([]);

  const handleMediaCapture = (newMedia) => {
    setMedia(newMedia);
  };

  const handleSaveMedia = (description) => {
    const updatedMedia = { ...media, description };
    setSavedMedia([...savedMedia, updatedMedia]);
    setMedia(null);
    Alert.alert('Media Saved!', 'Your media has been saved successfully.');
  };

  return (
    <View style={styles.container}>
      {!media ? (
        <CapturaImgvideo onCapture={handleMediaCapture} />
      ) : (
        <Display media={media} onSave={handleSaveMedia} onCancel={() => setMedia(null)} />
      )}
      <ScrollView>
        <SavedMediaList mediaList={savedMedia} />
      </ScrollView>
    </View>
  );
};

export default App;
